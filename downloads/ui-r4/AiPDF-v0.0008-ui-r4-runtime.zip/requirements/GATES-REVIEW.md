첨부 계약 적용 후 게이트 판정

| 게이트 | 상태 | 확인 내용·남은 요구 |
|---|---|---|
| G0 BoltPDF | BLOCKED | 원본/SDK/라이선스 없음. 실제 파일 및 ZIP 검색과 현재 PE imports 검사 완료 |
| G1 공통 Custom UI | PASS (Wine 범위) | Direct2D/DirectWrite/WIC, 25/75 배치, 공유 원본·실제 HDROP·초 시계/음력·상단 단계·편집 보존 구현. 3회×230개 통합 GUI 확인. 실제 Windows/고DPI는 G9 미검증 |
| G2 고속 렌더링 | FAIL | MuPDF C API 메모리 미리보기 있음. 600 DPI 확대/타일/비동기 UI/대형 도면 캐시 검증 없음 |
| G3 전체 PDF 편집 | FAIL | 회전·삭제·저장 등 부분 기능만 검증. 전체 내용 편집·OCR·변환·서명·보안 등 미완료 |
| G4 분리·Excel | 부분 검증 | 직전 확정의 4형식·공통 대장·명시 적용 구현. 자체 판독은 표시가 있는 텍스트 PDF 한정, 실제 AI/OCR BLOCKED |
| G5 메뉴 3 게이트 | PASS (제한 범위: Wine) | 실제 분리 매핑 강제·자동 재검사·실패 시 메뉴2 유지·복구 PASS 후 복귀·경고 중복 방지 추가. 새 공통 화면에서 3회×230개 통합 GUI 확인; 실제 Windows 음향은 UNVERIFIED |
| G6 6-AI 큐 | FAIL | 실제 6서비스 연결·한도·중단 복구·중복 방지 UI 미구현 |
| G7 최종 Word | FAIL | 저장된 구조화 결과의 AI별 Word 정렬은 존재. 공통 단일 폴더 약칭 파일명, 최종 근거/충돌 통합 보고서는 미완료 |
| G8 상태/잠금/알림 | FAIL | 일부 입력 해시·작업 복구·저장 보호 있음. 전체 작업 잠금·재개·최종 보고서 완료 강제·완료음3회는 미완료 |
| G9 전체 포터블 | UNVERIFIED | 제한된 기능의 Win64 정적 빌드와 Wine 실행은 확인. 전체 기능/물리 Windows 10·11 통합 합격 아님 |

현재 프로그램의 ‘작업 완료’는 기존 작업 폴더 이동 기능입니다. 새로운 전체 계약의 최종 AI 보고서 완료를 보증하는 기능으로 사용하면 안 됩니다.
G0 증거: evidence/G0-contract/inspection.json, pe-imports.log, native-api.log.
현재 요구 우선순위: requirements/PRECEDENCE.md.
