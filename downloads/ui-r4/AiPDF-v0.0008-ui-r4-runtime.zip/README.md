Ai PDF v0.0008 · UI-r4 작업본

Windows x64 포터블 실행 파일입니다. 본체는 C17 + Win32이며 공통 화면은 Direct2D/DirectWrite, PDF 미리보기는 MuPDF → 메모리 → WIC/Direct2D 경로를 사용합니다. 사용자 Python·Visual Studio 설치가 필요하지 않습니다.

상단에서 PDF를 열거나 창에 PDF를 놓으면 원본 경로·쪽수·책갈피 정보가 등록됩니다. 세 메뉴가 같은 원본을 공유합니다. 메뉴 1의 미저장 편집은 원본 교체 취소 및 메뉴 전환에서 보호됩니다. 메뉴 2에서는 네 가지 형식 중 하나를 선택하고 분석 결과를 확인한 다음 파일명변경을 눌러 적용합니다. 메뉴 3은 실제 분리 PDF·공통 Excel 검사 후에만 활성화됩니다.

전체 계약은 아직 미완료입니다. 기준 우선순위는 requirements/PRECEDENCE.md, 전체 게이트 판정은 requirements/GATES-REVIEW.md, 현재 검증 범위와 제한은 RELEASE-STATUS.md를 확인하세요. 무료 AI 6개 자동 작업 큐와 최종 단일 통합 보고서는 미구현입니다. 상세 AI 매뉴얼은 사용자 요청에 따라 완성 후 수정 단계에서 추가합니다.

검증: evidence/g1-common-gui-stage1/2/3.log는 각 230개 실제 Wine Win64 GUI 확인과 저장 PDF 독립 렌더링의 화면 대조를 담고 있습니다. AI 연결 회귀 시험은 모의 로컬 서버 응답이며 실제 모델 판독 정확도의 증거가 아닙니다. 물리 Windows 10/11 통합 시험은 UNVERIFIED입니다.

소스 빌드와 자동 시험 스크립트는 tools/ 및 tests/에 있습니다. 음력은 MIT 라이선스 변환 데이터를 빌드 시 내장했으며 2000-01-01~2050-12-31 범위를 지원합니다. 프로그램 실행 중 Python이나 인터넷으로 달력 데이터를 조회하지 않습니다.
